/* ============================================================
   Memoli – Coming Soon Page
   Vanilla JS + GSAP animations (no framework)
   ============================================================ */

(function () {
  "use strict";

  /* ----- Wait for DOM + images ----- */
  window.addEventListener("DOMContentLoaded", init);

  function init() {
    animateBackground();
    animateEntrance();
    setupCardHovers();
    setupGlobalUnflip();
  }
  /* ===========================================================
     4. Global click – unflip all cards when clicking outside
     =========================================================== */
  function setupGlobalUnflip() {
    document.addEventListener("click", function (e) {
      var cards = document.querySelectorAll(".card");
      // If click is inside any card, do nothing
      if (e.target.closest('.card')) return;
      // Otherwise, unflip all
      cards.forEach(function(card) {
        card.classList.remove("is-flipped");
      });
    });
  }

  /* ===========================================================
     1. Ambient background – floating orbs
     =========================================================== */
  function animateBackground() {
    const orbs = document.querySelectorAll(".bg-orb");
    orbs.forEach(function (orb, i) {
      gsap.to(orb, {
        y: gsap.utils.random(-30, 30),
        x: gsap.utils.random(-20, 20),
        duration: 5 + i * 1.2,
        repeat: -1,
        yoyo: true,
        ease: "sine.inOut",
      });
    });
  }

  /* ===========================================================
     2. Entrance timeline – staggered reveal
     =========================================================== */
  function animateEntrance() {
    var tl = gsap.timeline({
      defaults: { ease: "power3.out" },
    });

    /* Banner logo */
    tl.fromTo(
      "#heroBanner",
      { opacity: 0, y: -30, scale: 0.95 },
      { opacity: 1, y: 0, scale: 1, duration: 1 },
      0
    );

    /* Cards – stagger one by one with flip entrance */
    var cards = document.querySelectorAll(".card");
    cards.forEach(function (card, i) {
      var inner = card.querySelector(".card__inner");

      /* Card fades + slides up */
      tl.fromTo(
        card,
        { opacity: 0, y: 50, scale: 0.8 },
        { opacity: 1, y: 0, scale: 1, duration: 0.6, ease: "back.out(1.4)" },
        0.5 + i * 0.12
      );

      /* Card inner does a full flip reveal */
      tl.fromTo(
        inner,
        { rotationY: 180 },
        {
          rotationY: 360,
          duration: 0.8,
          ease: "power2.inOut",
          onComplete: function () {
            /* Reset to 0 so CSS hover flip (0→180) works naturally */
            gsap.set(inner, { rotationY: 0, clearProps: "transform" });
          },
        },
        0.6 + i * 0.12
      );
    });
  }

  /* ===========================================================
     3. Card hover – GSAP-powered lift & shadow
     =========================================================== */
  function setupCardHovers() {
    var cards = document.querySelectorAll(".card");

    cards.forEach(function (card) {
      card.addEventListener("mouseenter", function () {
        gsap.to(card, {
          scale: 1.08,
          duration: 0.35,
          ease: "power2.out",
        });
      });

      card.addEventListener("mouseleave", function () {
        gsap.to(card, {
          scale: 1,
          duration: 0.35,
          ease: "power2.out",
        });
      });

      /* Touch: toggle flip class */
      card.addEventListener("click", function () {
        card.classList.toggle("is-flipped");
      });
    });
  }
})();
